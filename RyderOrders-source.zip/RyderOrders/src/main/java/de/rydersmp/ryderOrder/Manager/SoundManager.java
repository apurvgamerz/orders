package de.rydersmp.ryderOrder.Manager;

import de.rydersmp.ryderOrder.Order;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

public class SoundManager {

    private final Order plugin;

    public SoundManager(Order plugin) {
        this.plugin = plugin;
    }

    private void playSound(Player player, String key) {
        boolean enabled = plugin.getConfig().getBoolean("sounds." + key + ".enabled", true);
        if (!enabled) return;
        String soundName = plugin.getConfig().getString("sounds." + key + ".sound", "UI_BUTTON_CLICK");
        try {
            Sound sound = Sound.valueOf(soundName);
            player.playSound(player.getLocation(), sound, 1f, 1f);
        } catch (IllegalArgumentException ignored) {}
    }

    public void playClick(Player player) { playSound(player, "gui-click"); }
    public void playRefresh(Player player) { playSound(player, "refresh-gui"); }
    public void playError(Player player) { playSound(player, "error"); }
}
