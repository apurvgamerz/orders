package de.rydersmp.ryderOrder.Manager;

import de.rydersmp.ryderOrder.Order;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.*;

public class OrderManager {

    private final Order plugin;
    // Stores pending new-order data per player UUID
    private final Map<UUID, Material> selectedMaterial = new HashMap<>();
    private final Map<UUID, Integer> selectedAmount = new HashMap<>();
    private final Map<UUID, Double> selectedPrice = new HashMap<>();

    public OrderManager(Order plugin) {
        this.plugin = plugin;
    }

    // ---- Session helpers ----

    public void setMaterial(UUID uuid, Material mat) { selectedMaterial.put(uuid, mat); }
    public void setAmount(UUID uuid, int amount) { selectedAmount.put(uuid, amount); }
    public void setPrice(UUID uuid, double price) { selectedPrice.put(uuid, price); }

    public Material getMaterial(UUID uuid) { return selectedMaterial.getOrDefault(uuid, Material.STONE); }
    public int getAmount(UUID uuid) { return selectedAmount.getOrDefault(uuid, 1); }
    public double getPrice(UUID uuid) { return selectedPrice.getOrDefault(uuid, 1.0); }

    public void clearSession(UUID uuid) {
        selectedMaterial.remove(uuid);
        selectedAmount.remove(uuid);
        selectedPrice.remove(uuid);
    }

    // ---- Limit helpers ----

    public int getOrderLimit(Player player) {
        for (int i = 44; i >= 1; i--) {
            if (player.hasPermission("order.limit." + i)) return i;
        }
        return 1; // default 1 order
    }

    public boolean canCreateOrder(Player player) {
        int count = plugin.getDataManager().getOrderCountByOwner(player.getUniqueId().toString());
        return count < getOrderLimit(player);
    }

    // ---- Economy helpers ----

    public Economy getEconomy() {
        return plugin.getEconomy();
    }

    public String formatCurrency(double amount) {
        String format = plugin.getConfig().getString("economy.currency-format", "#,##0.##");
        boolean abbrev = plugin.getConfig().getBoolean("economy.abbreviations.enabled", true);
        if (abbrev) {
            List<String> fmts = plugin.getConfig().getStringList("economy.abbreviations.formats");
            String[] suffixes = fmts.isEmpty()
                    ? new String[]{"K", "M", "B", "T"}
                    : fmts.toArray(new String[0]);
            double[] thresholds = {1_000, 1_000_000, 1_000_000_000, 1_000_000_000_000.0};
            for (int i = thresholds.length - 1; i >= 0; i--) {
                if (amount >= thresholds[i] && i < suffixes.length) {
                    return new DecimalFormat(format).format(amount / thresholds[i]) + suffixes[i];
                }
            }
        }
        return new DecimalFormat(format).format(amount);
    }

    // ---- Source item lore builder ----

    public List<String> buildSourceLore(Map<String, Object> order) {
        long createdAt = ((Number) order.get("created_at")).longValue();
        long expireSeconds = plugin.getConfig().getLong("expire-time-seconds", 604800);
        long remaining = TimeChecker.secondsRemaining(createdAt, expireSeconds);

        int reqAmount = ((Number) order.get("amount")).intValue();
        int delivered = ((Number) order.get("delivered")).intValue();
        double priceEach = ((Number) order.get("price_per_item")).doubleValue();
        double paidAmount = ((Number) order.get("paid_amount")).doubleValue();
        double totalPaid = priceEach * reqAmount;

        List<String> configLore = plugin.getConfig().getStringList("source-item.lore");
        if (configLore.isEmpty()) {
            configLore = List.of(
                    "&#00fc88%requested-amount% &f%requested-material%",
                    "&#00fc88%price% &feach",
                    "",
                    "&#80802a%delivered-amount%/&#008f4d%required-amount% &7Delivered",
                    "&#80802a%paid-amount%/&#008f4d%total-paid-amount% &7Paid",
                    "",
                    "&fClick to deliver &#00fc88%owner% &f%requested-material%",
                    "&8%expire-time% Until Order expires"
            );
        }

        List<String> result = new ArrayList<>();
        for (String line : configLore) {
            line = line
                    .replace("%requested-amount%", String.valueOf(reqAmount))
                    .replace("%requested-material%", order.get("material").toString())
                    .replace("%price%", formatCurrency(priceEach))
                    .replace("%delivered-amount%", String.valueOf(delivered))
                    .replace("%required-amount%", String.valueOf(reqAmount))
                    .replace("%paid-amount%", formatCurrency(paidAmount))
                    .replace("%total-paid-amount%", formatCurrency(totalPaid))
                    .replace("%owner%", order.get("owner").toString())
                    .replace("%expire-time%", TimeChecker.formatTime(remaining));
            result.add(line);
        }
        return result;
    }
}
