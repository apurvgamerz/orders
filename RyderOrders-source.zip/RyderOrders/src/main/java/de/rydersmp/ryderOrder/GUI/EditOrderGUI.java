package de.rydersmp.ryderOrder.GUI;

import de.rydersmp.ryderOrder.Order;
import de.rydersmp.ryderOrder.utils.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class EditOrderGUI {

    private final Order plugin;

    public EditOrderGUI(Order plugin) {
        this.plugin = plugin;
    }

    public void open(Player player, Map<String, Object> order) {
        Inventory inv = Bukkit.createInventory(null, 27,
                ColorUtil.colorize("&8ʀʏᴅᴇʀᴏʀᴅᴇʀs -> Edit Order"));

        // Background glass
        ItemStack glass = GUIBuilder.buildItem(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int slot : new int[]{0, 1, 2, 9, 11, 19, 20}) {
            inv.setItem(slot, glass);
        }

        // Source item
        Material mat;
        try { mat = Material.valueOf((String) order.get("material")); }
        catch (Exception e) { mat = Material.STONE; }

        List<String> lore = plugin.getOrderManager().buildSourceLore(order);
        List<String> coloredLore = new ArrayList<>();
        for (String line : lore) coloredLore.add(ColorUtil.colorize(line));

        ItemStack sourceItem = new ItemStack(mat);
        ItemMeta sourceMeta = sourceItem.getItemMeta();
        if (sourceMeta != null) {
            sourceMeta.setDisplayName(ColorUtil.colorize("&#00fc88" + order.get("owner") + "s Order"));
            sourceMeta.setLore(coloredLore);
            sourceMeta.getPersistentDataContainer().set(
                    new org.bukkit.NamespacedKey(Order.getInstance(), "order_id"),
                    org.bukkit.persistence.PersistentDataType.INTEGER,
                    ((Number) order.get("id")).intValue()
            );
            sourceItem.setItemMeta(sourceMeta);
        }
        inv.setItem(10, sourceItem);

        // Cancel order
        inv.setItem(13, GUIBuilder.buildItem(Material.RED_TERRACOTTA,
                ColorUtil.colorize("&#00fc88ᴄᴀɴᴄᴇʟ"),
                List.of(ColorUtil.colorize("&fClick to cancel this order"))));

        // Collect items
        String collectStr = (String) order.getOrDefault("items_to_collect", "");
        boolean hasItems = collectStr != null && !collectStr.isEmpty();
        if (hasItems) {
            inv.setItem(15, GUIBuilder.buildItem(Material.CHEST,
                    ColorUtil.colorize("&#00fc88ᴄᴏʟʟᴇᴄᴛ ɪᴛᴇᴍꜱ"),
                    List.of(ColorUtil.colorize("&fClick to collect items"))));
        } else {
            inv.setItem(15, GUIBuilder.buildItem(Material.CHEST,
                    ColorUtil.colorize("&#00fc88ɴᴏ ᴄᴏʟʟᴇᴄᴛ ɪᴛᴇᴍꜱ"),
                    List.of(ColorUtil.colorize("&cNo Items to collect"))));
        }

        // Back
        inv.setItem(18, GUIBuilder.buildItem(Material.RED_STAINED_GLASS_PANE,
                ColorUtil.colorize("&#00fc88ʙᴀᴄᴋ"),
                List.of(ColorUtil.colorize("&fClick to go back"))));

        player.openInventory(inv);
    }
}
