package de.rydersmp.ryderOrder.GUI;

import de.rydersmp.ryderOrder.Order;
import de.rydersmp.ryderOrder.utils.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.List;
import java.util.UUID;

public class NewOrderGUI {

    private final Order plugin;

    public NewOrderGUI(Order plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        UUID uuid = player.getUniqueId();
        Material selectedMat = plugin.getOrderManager().getMaterial(uuid);
        int amount = plugin.getOrderManager().getAmount(uuid);
        double price = plugin.getOrderManager().getPrice(uuid);
        double total = price * amount;

        Inventory inv = Bukkit.createInventory(null, 27,
                ColorUtil.colorize("&8ʀʏᴅᴇʀᴏʀᴅᴇʀs -> New Order"));

        // Cancel
        inv.setItem(10, GUIBuilder.buildItem(Material.RED_STAINED_GLASS_PANE,
                ColorUtil.colorize("&#fc0404ᴄᴀɴᴄᴇʟ"),
                List.of(ColorUtil.colorize("&fClick to return"))));

        // Item selector
        inv.setItem(12, GUIBuilder.buildItem(selectedMat,
                ColorUtil.colorize("&#00fc88ɪᴛᴇᴍ"),
                List.of(ColorUtil.colorize("&fClick to choose the item"),
                        ColorUtil.colorize("&7(" + selectedMat.name() + ")"))));

        // Amount
        inv.setItem(13, GUIBuilder.buildItem(Material.CHEST,
                ColorUtil.colorize("&#00fc88ᴀᴍᴏᴜɴᴛ"),
                List.of(ColorUtil.colorize("&fClick to type amount of items"),
                        ColorUtil.colorize("&7(" + plugin.getOrderManager().formatCurrency(amount) + ")"))));

        // Price
        inv.setItem(14, GUIBuilder.buildItem(Material.EMERALD,
                ColorUtil.colorize("&#00fc88ᴘʀɪᴄᴇ"),
                List.of(ColorUtil.colorize("&fClick to type the price per item"),
                        ColorUtil.colorize("&7(" + plugin.getOrderManager().formatCurrency(price) + ")"))));

        // Confirm
        inv.setItem(16, GUIBuilder.buildItem(Material.LIME_STAINED_GLASS_PANE,
                ColorUtil.colorize("&#04fc04ᴄᴏɴғɪʀᴍ"),
                List.of(ColorUtil.colorize("&fClick to confirm order"),
                        ColorUtil.colorize("&7(Total: " + plugin.getOrderManager().formatCurrency(total) + ")"))));

        player.openInventory(inv);
    }
}
