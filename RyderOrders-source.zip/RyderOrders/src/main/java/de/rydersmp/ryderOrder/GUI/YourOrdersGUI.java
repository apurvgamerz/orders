package de.rydersmp.ryderOrder.GUI;

import de.rydersmp.ryderOrder.Order;
import de.rydersmp.ryderOrder.utils.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class YourOrdersGUI {

    private final Order plugin;

    public YourOrdersGUI(Order plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27,
                ColorUtil.colorize("&8ʀʏᴅᴇʀᴏʀᴅᴇʀs -> Your Orders"));

        // New Order button
        inv.setItem(0, GUIBuilder.buildItem(Material.MAP,
                ColorUtil.colorize("&#00fc88ɴᴇᴡ ᴏʀᴅᴇʀ"),
                List.of(ColorUtil.colorize("&fClick to create a new order"))));

        // Player's orders in slots 9-26
        List<Map<String, Object>> orders = plugin.getDataManager().getOrdersByOwner(player.getUniqueId().toString());
        int slot = 9;
        for (Map<String, Object> order : orders) {
            if (slot >= 27) break;
            inv.setItem(slot++, buildOrderItem(order));
        }

        player.openInventory(inv);
    }

    private ItemStack buildOrderItem(Map<String, Object> order) {
        Material mat;
        try { mat = Material.valueOf((String) order.get("material")); }
        catch (Exception e) { mat = Material.STONE; }

        List<String> lore = plugin.getOrderManager().buildSourceLore(order);
        List<String> coloredLore = new ArrayList<>();
        for (String line : lore) coloredLore.add(ColorUtil.colorize(line));
        coloredLore.add("");
        coloredLore.add(ColorUtil.colorize("&eClick to manage this order"));

        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ColorUtil.colorize("&#00fc88" + order.get("owner") + "s Order"));
            meta.setLore(coloredLore);
            meta.getPersistentDataContainer().set(
                    new org.bukkit.NamespacedKey(Order.getInstance(), "order_id"),
                    org.bukkit.persistence.PersistentDataType.INTEGER,
                    ((Number) order.get("id")).intValue()
            );
            item.setItemMeta(meta);
        }
        return item;
    }
}
