package de.rydersmp.ryderOrder.Manager;

import de.rydersmp.ryderOrder.Order;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.*;

public class MaterialsManager {

    private final Order plugin;
    private final List<Material> allMaterials = new ArrayList<>();

    public MaterialsManager(Order plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        allMaterials.clear();
        File file = new File(plugin.getDataFolder(), "items.yml");
        if (!file.exists()) plugin.saveResource("items.yml", false);
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(file);

        for (String key : cfg.getKeys(false)) {
            try {
                Material mat = Material.valueOf(key.toUpperCase());
                allMaterials.add(mat);
            } catch (IllegalArgumentException ignored) {}
        }

        if (allMaterials.isEmpty()) {
            // fallback: add all non-air materials
            for (Material mat : Material.values()) {
                if (mat.isItem() && mat != Material.AIR) allMaterials.add(mat);
            }
        }
    }

    public List<Material> getAll() { return Collections.unmodifiableList(allMaterials); }

    public List<Material> filter(String category) {
        if (category == null || category.equals("all")) return getAll();
        List<Material> result = new ArrayList<>();
        for (Material mat : allMaterials) {
            if (matchesCategory(mat, category)) result.add(mat);
        }
        return result;
    }

    public List<Material> search(String query) {
        String q = query.toLowerCase();
        List<Material> result = new ArrayList<>();
        for (Material mat : allMaterials) {
            if (mat.name().toLowerCase().contains(q)) result.add(mat);
        }
        return result;
    }

    private boolean matchesCategory(Material mat, String category) {
        String name = mat.name().toLowerCase();
        return switch (category.toLowerCase()) {
            case "blocks" -> mat.isBlock();
            case "tools" -> name.contains("pickaxe") || name.contains("axe") || name.contains("shovel") || name.contains("hoe");
            case "food" -> mat.isEdible();
            case "combat" -> name.contains("sword") || name.contains("bow") || name.contains("arrow") || name.contains("shield") || name.contains("crossbow") || name.contains("trident");
            case "potions" -> name.contains("potion") || name.contains("splash") || name.contains("lingering");
            case "books" -> name.contains("book") || name.contains("enchanted");
            case "ingredients" -> name.contains("dust") || name.contains("powder") || name.contains("shard") || name.contains("fragment") || name.contains("crystal");
            case "utilities" -> name.contains("bucket") || name.contains("flint") || name.contains("compass") || name.contains("clock") || name.contains("map");
            default -> true;
        };
    }
}
