package de.rydersmp.ryderOrder.Manager;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CollectItemsManager {

    private final Map<UUID, Integer> viewingCollect = new HashMap<>();

    public void setViewing(UUID uuid, int orderId) {
        viewingCollect.put(uuid, orderId);
    }

    public int getViewing(UUID uuid) {
        return viewingCollect.getOrDefault(uuid, -1);
    }

    public void clearViewing(UUID uuid) {
        viewingCollect.remove(uuid);
    }
}
