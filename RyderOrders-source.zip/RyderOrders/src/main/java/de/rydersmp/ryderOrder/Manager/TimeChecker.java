package de.rydersmp.ryderOrder.Manager;

public class TimeChecker {

    public static String formatTime(long secondsRemaining) {
        if (secondsRemaining <= 0) return "Expired";
        long days = secondsRemaining / 86400;
        long hours = (secondsRemaining % 86400) / 3600;
        long minutes = (secondsRemaining % 3600) / 60;
        if (days > 0) return days + "d " + hours + "h";
        if (hours > 0) return hours + "h " + minutes + "m";
        return minutes + "m";
    }

    public static boolean isExpired(long createdAt, long expireSeconds) {
        return (System.currentTimeMillis() / 1000) - createdAt > expireSeconds;
    }

    public static long secondsRemaining(long createdAt, long expireSeconds) {
        long elapsed = (System.currentTimeMillis() / 1000) - createdAt;
        return Math.max(0, expireSeconds - elapsed);
    }
}
