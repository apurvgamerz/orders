package de.rydersmp.ryderOrder.Manager;

import de.rydersmp.ryderOrder.Order;
import de.rydersmp.ryderOrder.utils.ColorUtil;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;

public class LangManager {

    private final Order plugin;
    private FileConfiguration lang;

    public LangManager(Order plugin) {
        this.plugin = plugin;
        loadLang();
    }

    public void loadLang() {
        File file = new File(plugin.getDataFolder(), "lang.yml");
        if (!file.exists()) plugin.saveResource("lang.yml", false);
        lang = YamlConfiguration.loadConfiguration(file);
    }

    public String getPrefix() {
        if (lang.getBoolean("prefix-enable", true)) {
            return ColorUtil.colorize(lang.getString("prefix", "&#00fc88ʀʏᴅᴇʀᴏʀᴅᴇʀ &7» "));
        }
        return "";
    }

    public String getMessage(String key) {
        String raw = lang.getString("messages." + key, "&cMissing message: " + key);
        return getPrefix() + ColorUtil.colorize(raw);
    }

    public String getMessageRaw(String key) {
        return ColorUtil.colorize(lang.getString("messages." + key, "&cMissing: " + key));
    }

    public void sendMessage(Player player, String key) {
        player.sendMessage(getMessage(key));
    }

    public void sendMessage(Player player, String key, String... replacements) {
        String msg = getMessage(key);
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            msg = msg.replace(replacements[i], replacements[i + 1]);
        }
        player.sendMessage(msg);
    }

    public String getCommandUsage() {
        return ColorUtil.colorize(lang.getString("command-usage", ""));
    }

    public String getCommandUsageAdmin() {
        return ColorUtil.colorize(lang.getString("command-usage-admin", ""));
    }
}
