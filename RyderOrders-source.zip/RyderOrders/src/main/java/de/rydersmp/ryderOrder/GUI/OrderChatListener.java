package de.rydersmp.ryderOrder.GUI;

import de.rydersmp.ryderOrder.Order;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import java.util.function.Consumer;

public class OrderChatListener implements Listener {

    private final Order plugin;

    public OrderChatListener(Order plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        Consumer<String> callback = plugin.getChatInputSessions().remove(player.getUniqueId());
        if (callback == null) return;

        event.setCancelled(true);
        String input = event.getMessage().trim();

        if (input.equalsIgnoreCase("cancel")) {
            plugin.getLangManager().sendMessage(player, "chat-input-cancel");
            return;
        }

        plugin.getServer().getScheduler().runTask(plugin, () -> callback.accept(input));
    }
}
