package de.rydersmp.ryderOrder.GUI;

import de.rydersmp.ryderOrder.Order;
import de.rydersmp.ryderOrder.utils.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.Map;

public class CollectItemsGUI {

    private final Order plugin;

    public CollectItemsGUI(Order plugin) {
        this.plugin = plugin;
    }

    public void open(Player player, Map<String, Object> order) {
        Inventory inv = Bukkit.createInventory(null, 54,
                ColorUtil.colorize("&8ʀʏᴅᴇʀᴏʀᴅᴇʀs -> Collect Items"));

        String collectStr = (String) order.getOrDefault("items_to_collect", "");
        int slot = 0;
        if (collectStr != null && !collectStr.isEmpty()) {
            for (String entry : collectStr.split(",")) {
                if (slot >= 45) break;
                String[] parts = entry.split(":");
                if (parts.length < 2) continue;
                try {
                    Material mat = Material.valueOf(parts[0]);
                    int amount = Integer.parseInt(parts[1]);
                    ItemStack item = new ItemStack(mat, Math.min(amount, 64));
                    ItemMeta meta = item.getItemMeta();
                    if (meta != null) {
                        meta.setDisplayName(ColorUtil.colorize("&#00fc88" + mat.name()));
                        meta.setLore(List.of(ColorUtil.colorize("&7Amount: &f" + amount)));
                        item.setItemMeta(meta);
                    }
                    inv.setItem(slot++, item);
                } catch (Exception ignored) {}
            }
        }

        // Drop loot button
        inv.setItem(49, GUIBuilder.buildItem(Material.DISPENSER,
                ColorUtil.colorize("&#00fc88ᴅʀᴏᴘ ʟᴏᴏᴛ"),
                List.of(ColorUtil.colorize("&fClick to drop all loot on the page"))));

        player.openInventory(inv);
    }
}
