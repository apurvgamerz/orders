package de.rydersmp.ryderOrder.GUI;

import de.rydersmp.ryderOrder.Manager.ConfirmDeliveryManager;
import de.rydersmp.ryderOrder.Manager.OrderDeliveryManager;
import de.rydersmp.ryderOrder.Order;
import de.rydersmp.ryderOrder.utils.ColorUtil;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.Map;
import java.util.UUID;

public class OrderViewHandler implements Listener {

    private final Order plugin;
    private final NamespacedKey orderIdKey;

    // Track current page/filter/sort per player
    private final java.util.Map<UUID, Integer> playerPage = new java.util.HashMap<>();
    private final java.util.Map<UUID, String> playerSort = new java.util.HashMap<>();
    private final java.util.Map<UUID, String> playerFilter = new java.util.HashMap<>();

    public OrderViewHandler(Order plugin) {
        this.plugin = plugin;
        this.orderIdKey = new NamespacedKey(plugin, "order_id");
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        String title = event.getView().getTitle();
        if (!title.contains("ʀʏᴅᴇʀᴏʀᴅᴇʀs")) return;

        event.setCancelled(true);
        if (event.getCurrentItem() == null || event.getCurrentItem().getType() == Material.AIR) return;

        plugin.getSoundManager().playClick(player);
        UUID uuid = player.getUniqueId();
        ItemStack clicked = event.getCurrentItem();
        ItemMeta meta = clicked.getItemMeta();

        // --- MAIN ORDER VIEW ---
        if (title.contains("ʀʏᴅᴇʀᴏʀᴅᴇʀs (Page")) {
            int page = playerPage.getOrDefault(uuid, 1);
            String sort = playerSort.getOrDefault(uuid, "most_recent");
            String filter = playerFilter.getOrDefault(uuid, "all");
            int slot = event.getSlot();

            if (slot == 45 && page > 1) { // prev
                playerPage.put(uuid, page - 1);
                plugin.getSoundManager().playRefresh(player);
                plugin.getOrderGUI().open(player, page - 1, sort, filter);
            } else if (slot == 53) { // next
                playerPage.put(uuid, page + 1);
                plugin.getSoundManager().playRefresh(player);
                plugin.getOrderGUI().open(player, page + 1, sort, filter);
            } else if (slot == 49) { // refresh
                plugin.getSoundManager().playRefresh(player);
                plugin.getOrderGUI().open(player, page, sort, filter);
            } else if (slot == 51) { // your orders
                plugin.getYourOrdersGUI().open(player);
            } else if (slot < 45 && meta != null) {
                // Clicked an order item
                Integer orderId = meta.getPersistentDataContainer().get(orderIdKey, PersistentDataType.INTEGER);
                if (orderId != null) {
                    Map<String, Object> order = plugin.getDataManager().getOrderById(orderId);
                    if (order != null) {
                        plugin.getConfirmDeliveryManager().setPending(uuid, orderId, 64);
                        plugin.getConfirmDeliveryGUI().open(player, order, 64);
                    }
                }
            }
            return;
        }

        // --- YOUR ORDERS ---
        if (title.contains("Your Orders")) {
            int slot = event.getSlot();
            if (slot == 0) { // new order
                if (!plugin.getOrderManager().canCreateOrder(player)) {
                    plugin.getLangManager().sendMessage(player, "max-orders-reached",
                            "%max%", String.valueOf(plugin.getOrderManager().getOrderLimit(player)));
                    plugin.getSoundManager().playError(player);
                    return;
                }
                plugin.getNewOrderGUI().open(player);
            } else if (meta != null) {
                Integer orderId = meta.getPersistentDataContainer().get(orderIdKey, PersistentDataType.INTEGER);
                if (orderId != null) {
                    Map<String, Object> order = plugin.getDataManager().getOrderById(orderId);
                    if (order != null) {
                        plugin.getEditOrderManager().setViewingOrder(uuid, orderId);
                        plugin.getEditOrderGUI().open(player, order);
                    }
                }
            }
            return;
        }

        // --- NEW ORDER ---
        if (title.contains("New Order")) {
            int slot = event.getSlot();
            if (slot == 10) { // cancel
                plugin.getYourOrdersGUI().open(player);
            } else if (slot == 12) { // item selector
                plugin.getListMaterialsGUI().open(player, 1, "all", null);
            } else if (slot == 13) { // amount
                player.closeInventory();
                plugin.getLangManager().sendMessage(player, "chat-input", "%type%", "amount");
                plugin.getChatInputSessions().put(uuid, input -> {
                    try {
                        int amt = Integer.parseInt(input.trim());
                        int min = plugin.getConfig().getInt("minimum-item-per-order", 1);
                        int max = plugin.getConfig().getInt("maximum-item-per-order", -1);
                        if (amt < min) { plugin.getLangManager().sendMessage(player, "amount-too-low", "%min%", String.valueOf(min)); return; }
                        if (max > 0 && amt > max) { plugin.getLangManager().sendMessage(player, "amount-too-high", "%max%", String.valueOf(max)); return; }
                        plugin.getOrderManager().setAmount(uuid, amt);
                        plugin.getLangManager().sendMessage(player, "amount-set", "%amount%", String.valueOf(amt));
                        plugin.getNewOrderGUI().open(player);
                    } catch (NumberFormatException e) {
                        plugin.getLangManager().sendMessage(player, "error");
                    }
                });
            } else if (slot == 14) { // price
                player.closeInventory();
                plugin.getLangManager().sendMessage(player, "chat-input", "%type%", "price");
                plugin.getChatInputSessions().put(uuid, input -> {
                    try {
                        double price = Double.parseDouble(input.trim().replace(",", ""));
                        double min = plugin.getConfig().getDouble("minimum-price-per-item", 1);
                        double max = plugin.getConfig().getDouble("maximum-price-per-item", -1);
                        if (price < min) { plugin.getLangManager().sendMessage(player, "price-too-low", "%min%", String.valueOf((int)min)); return; }
                        if (max > 0 && price > max) { plugin.getLangManager().sendMessage(player, "price-too-high", "%max%", String.valueOf((int)max)); return; }
                        plugin.getOrderManager().setPrice(uuid, price);
                        plugin.getLangManager().sendMessage(player, "price-set", "%price%", plugin.getOrderManager().formatCurrency(price));
                        plugin.getNewOrderGUI().open(player);
                    } catch (NumberFormatException e) {
                        plugin.getLangManager().sendMessage(player, "error");
                    }
                });
            } else if (slot == 16) { // confirm
                Material mat = plugin.getOrderManager().getMaterial(uuid);
                int amount = plugin.getOrderManager().getAmount(uuid);
                double price = plugin.getOrderManager().getPrice(uuid);

                if (plugin.getEconomy() == null || !plugin.getEconomy().has(player, price)) {
                    plugin.getLangManager().sendMessage(player, "no-money");
                    plugin.getSoundManager().playError(player);
                    return;
                }

                plugin.getEconomy().withdrawPlayer(player, price);
                int orderId = plugin.getDataManager().createOrder(
                        player.getName(), uuid.toString(), mat, amount, price);
                plugin.getOrderManager().clearSession(uuid);

                plugin.getLangManager().sendMessage(player, "order-created",
                        "%amount%", String.valueOf(amount),
                        "%item%", mat.name(),
                        "%price%", plugin.getOrderManager().formatCurrency(price),
                        "%total_price%", plugin.getOrderManager().formatCurrency(price));

                if (plugin.getConfig().getBoolean("announce-orders", true)) {
                    String msg = ColorUtil.colorize(plugin.getConfig().getString("announce-message", "")
                            .replace("%owner%", player.getName())
                            .replace("%requested-amount%", String.valueOf(amount))
                            .replace("%requested-material%", mat.name())
                            .replace("%price%", plugin.getOrderManager().formatCurrency(price)));
                    plugin.getServer().broadcastMessage(msg);
                }

                plugin.getYourOrdersGUI().open(player);
            }
            return;
        }

        // --- LIST MATERIALS ---
        if (title.contains("Select Item")) {
            int slot = event.getSlot();
            if (slot < 45 && clicked.getType() != Material.AIR) {
                Material selected = clicked.getType();
                plugin.getOrderManager().setMaterial(uuid, selected);
                plugin.getLangManager().sendMessage(player, "item-set", "%item%", selected.name());
                plugin.getNewOrderGUI().open(player);
            } else if (slot == 45) {
                plugin.getListMaterialsGUI().open(player, 1, "all", null);
            } else if (slot == 53) {
                plugin.getListMaterialsGUI().open(player, 2, "all", null);
            }
            return;
        }

        // --- EDIT ORDER ---
        if (title.contains("Edit Order")) {
            int orderId = plugin.getEditOrderManager().getViewingOrder(uuid);
            Map<String, Object> order = orderId >= 0 ? plugin.getDataManager().getOrderById(orderId) : null;
            int slot = event.getSlot();
            if (slot == 13 && order != null) { // cancel order
                plugin.getConfirmCancelManager().setPending(uuid, orderId);
                plugin.getConfirmCancelGUI().open(player, order);
            } else if (slot == 15 && order != null) { // collect items
                String items = (String) order.getOrDefault("items_to_collect", "");
                if (items == null || items.isEmpty()) {
                    plugin.getLangManager().sendMessage(player, "no-items-to-collect");
                    plugin.getSoundManager().playError(player);
                } else {
                    plugin.getCollectItemsGUI().open(player, order);
                }
            } else if (slot == 18) { // back
                plugin.getYourOrdersGUI().open(player);
            }
            return;
        }

        // --- CONFIRM DELIVERY ---
        if (title.contains("Confirm Delivery")) {
            int slot = event.getSlot();
            ConfirmDeliveryManager.DeliveryData data = plugin.getConfirmDeliveryManager().getPending(uuid);
            if (slot == 11) { // cancel
                plugin.getConfirmDeliveryManager().clearPending(uuid);
                plugin.getOrderGUI().open(player, playerPage.getOrDefault(uuid, 1),
                        playerSort.getOrDefault(uuid, "most_recent"), playerFilter.getOrDefault(uuid, "all"));
            } else if (slot == 15 && data != null) { // confirm
                Map<String, Object> order = plugin.getDataManager().getOrderById(data.orderId);
                if (order == null) { plugin.getLangManager().sendMessage(player, "order-not-available"); return; }
                OrderDeliveryManager.DeliveryResult result = plugin.getOrderDeliveryManager().attemptDelivery(player, order, data.amount);
                plugin.getConfirmDeliveryManager().clearPending(uuid);
                switch (result) {
                    case SUCCESS -> {
                        plugin.getLangManager().sendMessage(player, "reward-messages",
                                "%reward%", plugin.getOrderManager().formatCurrency(
                                        ((Number) order.get("price_per_item")).doubleValue() * data.amount));
                        // Notify owner
                        plugin.getServer().getOnlinePlayers().stream()
                                .filter(p -> p.getUniqueId().toString().equals(order.get("owner_uuid")))
                                .findFirst()
                                .ifPresent(owner -> plugin.getLangManager().sendMessage(owner, "delivered-user",
                                        "%player%", player.getName(),
                                        "%amount%", String.valueOf(data.amount),
                                        "%item%", (String) order.get("material")));
                    }
                    case CANNOT_DELIVER_OWN -> { plugin.getLangManager().sendMessage(player, "cannot-deliver-own"); plugin.getSoundManager().playError(player); }
                    case NO_ITEMS -> { plugin.getLangManager().sendMessage(player, "no-items"); plugin.getSoundManager().playError(player); }
                    case EXPIRED -> { plugin.getLangManager().sendMessage(player, "expired"); plugin.getSoundManager().playError(player); }
                    case ALREADY_DELIVERED -> { plugin.getLangManager().sendMessage(player, "already-delivered"); plugin.getSoundManager().playError(player); }
                    default -> { plugin.getLangManager().sendMessage(player, "error"); plugin.getSoundManager().playError(player); }
                }
                plugin.getOrderGUI().open(player, playerPage.getOrDefault(uuid, 1),
                        playerSort.getOrDefault(uuid, "most_recent"), playerFilter.getOrDefault(uuid, "all"));
            }
            return;
        }

        // --- CONFIRM CANCEL ---
        if (title.contains("Cancel Order")) {
            int slot = event.getSlot();
            int orderId = plugin.getConfirmCancelManager().getPending(uuid);
            if (slot == 11) { // go back
                plugin.getConfirmCancelManager().clearPending(uuid);
                plugin.getLangManager().sendMessage(player, "cancelled-closed");
                plugin.getYourOrdersGUI().open(player);
            } else if (slot == 15 && orderId >= 0) { // confirm cancel
                Map<String, Object> order = plugin.getDataManager().getOrderById(orderId);
                if (order != null) {
                    plugin.getOrderDeliveryManager().cancelOrder(player, order);
                    plugin.getLangManager().sendMessage(player, "order-cancelled-success");
                }
                plugin.getConfirmCancelManager().clearPending(uuid);
                plugin.getYourOrdersGUI().open(player);
            }
            return;
        }

        // --- COLLECT ITEMS ---
        if (title.contains("Collect Items")) {
            int slot = event.getSlot();
            int orderId = plugin.getEditOrderManager().getViewingOrder(uuid);
            if (slot == 49 && orderId >= 0) { // drop loot / collect all
                Map<String, Object> order = plugin.getDataManager().getOrderById(orderId);
                if (order != null) {
                    OrderDeliveryManager.CollectResult result = plugin.getOrderDeliveryManager().collectItems(player, order);
                    switch (result) {
                        case SUCCESS -> plugin.getLangManager().sendMessage(player, "items-collected",
                                "%amount%", "items", "%item%", "");
                        case NOTHING_TO_COLLECT -> { plugin.getLangManager().sendMessage(player, "no-items-to-collect"); plugin.getSoundManager().playError(player); }
                        case INVENTORY_FULL -> { plugin.getLangManager().sendMessage(player, "inventory-full"); plugin.getSoundManager().playError(player); }
                    }
                    plugin.getYourOrdersGUI().open(player);
                }
            }
        }
    }
}
