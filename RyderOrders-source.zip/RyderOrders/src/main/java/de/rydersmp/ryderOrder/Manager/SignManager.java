package de.rydersmp.ryderOrder.Manager;

import de.rydersmp.ryderOrder.Order;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerEditBookEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

public class SignManager implements Listener {

    public static class SignSession {
        public String type;
        public Consumer<String> callback;
        public SignSession(String type, Consumer<String> callback) {
            this.type = type;
            this.callback = callback;
        }
    }

    private final Order plugin;
    private final Map<UUID, SignSession> sessions = new HashMap<>();

    public SignManager(Order plugin) {
        this.plugin = plugin;
    }

    public void openInput(Player player, String type, Consumer<String> callback) {
        sessions.put(player.getUniqueId(), new SignSession(type, callback));
        // In a full implementation this would open a sign editor
        // For now, fallback to chat input
        plugin.getLangManager().sendMessage(player, "chat-input", "%type%", type);
        plugin.getChatInputSessions().put(player.getUniqueId(), callback);
        sessions.remove(player.getUniqueId());
    }

    public boolean hasSession(UUID uuid) {
        return sessions.containsKey(uuid);
    }

    public SignSession getSession(UUID uuid) {
        return sessions.get(uuid);
    }

    public void clearSession(UUID uuid) {
        sessions.remove(uuid);
    }
}
