package de.rydersmp.ryderOrder.Manager;

import de.rydersmp.ryderOrder.Order;
import org.bukkit.Material;

import java.io.File;
import java.sql.*;
import java.util.*;

public class DataManager {

    private final Order plugin;
    private Connection connection;

    public DataManager(Order plugin) {
        this.plugin = plugin;
        connect();
        createTable();
    }

    private void connect() {
        try {
            File dbFile = new File(plugin.getDataFolder(), "ryderorders.db");
            connection = DriverManager.getConnection("jdbc:sqlite:" + dbFile.getAbsolutePath());
        } catch (SQLException e) {
            plugin.getLogger().severe("Could not connect to SQLite database: " + e.getMessage());
        }
    }

    private void createTable() {
        String sql = """
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                owner TEXT NOT NULL,
                owner_uuid TEXT NOT NULL,
                material TEXT NOT NULL,
                amount INTEGER NOT NULL,
                delivered INTEGER NOT NULL DEFAULT 0,
                price_per_item REAL NOT NULL,
                paid_amount REAL NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL,
                expired INTEGER NOT NULL DEFAULT 0,
                deleted INTEGER NOT NULL DEFAULT 0,
                items_to_collect TEXT
            )
            """;
        try (Statement stmt = connection.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            plugin.getLogger().severe("Could not create table: " + e.getMessage());
        }
    }

    public int createOrder(String owner, String ownerUuid, Material material, int amount, double pricePerItem) {
        String sql = "INSERT INTO orders (owner, owner_uuid, material, amount, price_per_item, created_at) VALUES (?,?,?,?,?,?)";
        try (PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, owner);
            ps.setString(2, ownerUuid);
            ps.setString(3, material.name());
            ps.setInt(4, amount);
            ps.setDouble(5, pricePerItem);
            ps.setLong(6, System.currentTimeMillis() / 1000);
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            plugin.getLogger().severe("Error creating order: " + e.getMessage());
        }
        return -1;
    }

    public List<Map<String, Object>> getActiveOrders() {
        return queryOrders("SELECT * FROM orders WHERE deleted=0 ORDER BY created_at DESC");
    }

    public List<Map<String, Object>> getOrdersByOwner(String ownerUuid) {
        String sql = "SELECT * FROM orders WHERE owner_uuid=? AND deleted=0";
        return queryOrdersWithParam(sql, ownerUuid);
    }

    public Map<String, Object> getOrderById(int id) {
        String sql = "SELECT * FROM orders WHERE id=?";
        List<Map<String, Object>> results = queryOrdersWithParam(sql, String.valueOf(id));
        return results.isEmpty() ? null : results.get(0);
    }

    public void updateDelivery(int orderId, int additionalDelivered, double additionalPaid) {
        String sql = "UPDATE orders SET delivered=delivered+?, paid_amount=paid_amount+? WHERE id=?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, additionalDelivered);
            ps.setDouble(2, additionalPaid);
            ps.setInt(3, orderId);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Error updating delivery: " + e.getMessage());
        }
    }

    public void cancelOrder(int orderId) {
        String sql = "UPDATE orders SET deleted=1 WHERE id=?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, orderId);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Error cancelling order: " + e.getMessage());
        }
    }

    public void expireOrder(int orderId) {
        String sql = "UPDATE orders SET expired=1 WHERE id=?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, orderId);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Error expiring order: " + e.getMessage());
        }
    }

    public int getOrderCountByOwner(String ownerUuid) {
        String sql = "SELECT COUNT(*) FROM orders WHERE owner_uuid=? AND deleted=0";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, ownerUuid);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            plugin.getLogger().severe("Error counting orders: " + e.getMessage());
        }
        return 0;
    }

    public void addCollectItem(int orderId, String materialName, int amount) {
        Map<String, Object> order = getOrderById(orderId);
        if (order == null) return;
        String existing = (String) order.getOrDefault("items_to_collect", "");
        String entry = materialName + ":" + amount;
        String updated = (existing == null || existing.isEmpty()) ? entry : existing + "," + entry;
        String sql = "UPDATE orders SET items_to_collect=? WHERE id=?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, updated);
            ps.setInt(2, orderId);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Error adding collect item: " + e.getMessage());
        }
    }

    public void clearCollectItems(int orderId) {
        String sql = "UPDATE orders SET items_to_collect='' WHERE id=?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, orderId);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Error clearing collect items: " + e.getMessage());
        }
    }

    private List<Map<String, Object>> queryOrders(String sql) {
        List<Map<String, Object>> list = new ArrayList<>();
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            ResultSetMetaData meta = rs.getMetaData();
            while (rs.next()) {
                Map<String, Object> row = new LinkedHashMap<>();
                for (int i = 1; i <= meta.getColumnCount(); i++) {
                    row.put(meta.getColumnName(i), rs.getObject(i));
                }
                list.add(row);
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Error querying orders: " + e.getMessage());
        }
        return list;
    }

    private List<Map<String, Object>> queryOrdersWithParam(String sql, String param) {
        List<Map<String, Object>> list = new ArrayList<>();
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, param);
            ResultSet rs = ps.executeQuery();
            ResultSetMetaData meta = rs.getMetaData();
            while (rs.next()) {
                Map<String, Object> row = new LinkedHashMap<>();
                for (int i = 1; i <= meta.getColumnCount(); i++) {
                    row.put(meta.getColumnName(i), rs.getObject(i));
                }
                list.add(row);
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Error querying orders with param: " + e.getMessage());
        }
        return list;
    }

    public void close() {
        try {
            if (connection != null && !connection.isClosed()) connection.close();
        } catch (SQLException ignored) {}
    }
}
