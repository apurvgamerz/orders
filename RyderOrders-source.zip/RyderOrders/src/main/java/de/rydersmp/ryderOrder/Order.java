package de.rydersmp.ryderOrder;

import de.rydersmp.ryderOrder.GUI.*;
import de.rydersmp.ryderOrder.Manager.*;
import de.rydersmp.ryderOrder.commands.OrderCommand;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

public class Order extends JavaPlugin {

    private static Order instance;

    // Managers
    private DataManager dataManager;
    private OrderManager orderManager;
    private MaterialsManager materialsManager;
    private LangManager langManager;
    private SoundManager soundManager;
    private EditOrderManager editOrderManager;
    private OrderDeliveryManager orderDeliveryManager;
    private ConfirmDeliveryManager confirmDeliveryManager;
    private ConfirmCancelManager confirmCancelManager;
    private CollectItemsManager collectItemsManager;

    // GUIs
    private OrderGUI orderGUI;
    private YourOrdersGUI yourOrdersGUI;
    private NewOrderGUI newOrderGUI;
    private ListMaterialsGUI listMaterialsGUI;
    private EditOrderGUI editOrderGUI;
    private ConfirmDeliveryGUI confirmDeliveryGUI;
    private ConfirmCancelGUI confirmCancelGUI;
    private CollectItemsGUI collectItemsGUI;

    // Economy
    private Economy economy;

    // Chat sessions
    private final Map<UUID, Consumer<String>> chatInputSessions = new HashMap<>();

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();

        // Setup economy
        if (getServer().getPluginManager().getPlugin("Vault") != null) {
            setupEconomy();
        } else {
            getLogger().warning("Vault not found! Economy features disabled.");
        }

        // Init managers
        langManager = new LangManager(this);
        soundManager = new SoundManager(this);
        dataManager = new DataManager(this);
        materialsManager = new MaterialsManager(this);
        orderManager = new OrderManager(this);
        editOrderManager = new EditOrderManager();
        orderDeliveryManager = new OrderDeliveryManager(this);
        confirmDeliveryManager = new ConfirmDeliveryManager();
        confirmCancelManager = new ConfirmCancelManager();
        collectItemsManager = new CollectItemsManager();

        // Init GUIs
        orderGUI = new OrderGUI(this);
        yourOrdersGUI = new YourOrdersGUI(this);
        newOrderGUI = new NewOrderGUI(this);
        listMaterialsGUI = new ListMaterialsGUI(this);
        editOrderGUI = new EditOrderGUI(this);
        confirmDeliveryGUI = new ConfirmDeliveryGUI(this);
        confirmCancelGUI = new ConfirmCancelGUI(this);
        collectItemsGUI = new CollectItemsGUI(this);

        // Register events
        getServer().getPluginManager().registerEvents(new OrderViewHandler(this), this);
        getServer().getPluginManager().registerEvents(new OrderChatListener(this), this);

        // Register commands
        OrderCommand cmd = new OrderCommand(this);
        getCommand("order").setExecutor(cmd);
        getCommand("orders").setExecutor(cmd);

        getLogger().info("RyderOrder enabled successfully!");
    }

    @Override
    public void onDisable() {
        if (dataManager != null) dataManager.close();
        getLogger().info("RyderOrder disabled.");
    }

    private boolean setupEconomy() {
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) return false;
        economy = rsp.getProvider();
        return economy != null;
    }

    public static Order getInstance() { return instance; }

    public DataManager getDataManager() { return dataManager; }
    public OrderManager getOrderManager() { return orderManager; }
    public MaterialsManager getMaterialsManager() { return materialsManager; }
    public LangManager getLangManager() { return langManager; }
    public SoundManager getSoundManager() { return soundManager; }
    public EditOrderManager getEditOrderManager() { return editOrderManager; }
    public OrderDeliveryManager getOrderDeliveryManager() { return orderDeliveryManager; }
    public ConfirmDeliveryManager getConfirmDeliveryManager() { return confirmDeliveryManager; }
    public ConfirmCancelManager getConfirmCancelManager() { return confirmCancelManager; }
    public CollectItemsManager getCollectItemsManager() { return collectItemsManager; }

    public OrderGUI getOrderGUI() { return orderGUI; }
    public YourOrdersGUI getYourOrdersGUI() { return yourOrdersGUI; }
    public NewOrderGUI getNewOrderGUI() { return newOrderGUI; }
    public ListMaterialsGUI getListMaterialsGUI() { return listMaterialsGUI; }
    public EditOrderGUI getEditOrderGUI() { return editOrderGUI; }
    public ConfirmDeliveryGUI getConfirmDeliveryGUI() { return confirmDeliveryGUI; }
    public ConfirmCancelGUI getConfirmCancelGUI() { return confirmCancelGUI; }
    public CollectItemsGUI getCollectItemsGUI() { return collectItemsGUI; }

    public Economy getEconomy() { return economy; }
    public Map<UUID, Consumer<String>> getChatInputSessions() { return chatInputSessions; }
}
