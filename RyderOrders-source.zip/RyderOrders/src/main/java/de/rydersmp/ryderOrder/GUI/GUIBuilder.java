package de.rydersmp.ryderOrder.GUI;

import de.rydersmp.ryderOrder.Order;
import de.rydersmp.ryderOrder.utils.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class GUIBuilder {

    public static ItemStack buildItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ColorUtil.colorize(name));
            List<String> coloredLore = new ArrayList<>();
            if (lore != null) {
                for (String line : lore) coloredLore.add(ColorUtil.colorize(line));
            }
            meta.setLore(coloredLore);
            item.setItemMeta(meta);
        }
        return item;
    }

    public static ItemStack buildItem(Material material, String name) {
        return buildItem(material, name, null);
    }

    public static ItemStack glassPane(Material pane, String name) {
        return buildItem(pane, name, null);
    }

    public static void fillBorder(Inventory inv, Material pane) {
        ItemStack glass = buildItem(pane, " ");
        int size = inv.getSize();
        int rows = size / 9;
        for (int i = 0; i < 9; i++) inv.setItem(i, glass); // top
        for (int i = size - 9; i < size; i++) inv.setItem(i, glass); // bottom
        for (int row = 1; row < rows - 1; row++) {
            inv.setItem(row * 9, glass);
            inv.setItem(row * 9 + 8, glass);
        }
    }
}
