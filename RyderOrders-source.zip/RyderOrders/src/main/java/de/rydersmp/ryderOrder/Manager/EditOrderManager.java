package de.rydersmp.ryderOrder.Manager;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class EditOrderManager {

    private final Map<UUID, Integer> viewingOrder = new HashMap<>();

    public void setViewingOrder(UUID uuid, int orderId) {
        viewingOrder.put(uuid, orderId);
    }

    public int getViewingOrder(UUID uuid) {
        return viewingOrder.getOrDefault(uuid, -1);
    }

    public void clearViewingOrder(UUID uuid) {
        viewingOrder.remove(uuid);
    }
}
