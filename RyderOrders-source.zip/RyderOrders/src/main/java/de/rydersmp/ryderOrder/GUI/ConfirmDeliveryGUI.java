package de.rydersmp.ryderOrder.GUI;

import de.rydersmp.ryderOrder.Order;
import de.rydersmp.ryderOrder.utils.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ConfirmDeliveryGUI {

    private final Order plugin;

    public ConfirmDeliveryGUI(Order plugin) {
        this.plugin = plugin;
    }

    public void open(Player player, Map<String, Object> order, int deliverAmount) {
        Inventory inv = Bukkit.createInventory(null, 27,
                ColorUtil.colorize("&8ʀʏᴅᴇʀᴏʀᴅᴇʀs -> Confirm Delivery"));

        // Cancel
        inv.setItem(11, GUIBuilder.buildItem(Material.RED_STAINED_GLASS_PANE,
                ColorUtil.colorize("&#fc0404ᴄᴀɴᴄᴇʟ"),
                List.of(ColorUtil.colorize("&fClick to go back"))));

        // Source item
        Material mat;
        try { mat = Material.valueOf((String) order.get("material")); }
        catch (Exception e) { mat = Material.STONE; }

        double priceEach = ((Number) order.get("price_per_item")).doubleValue();
        double payout = priceEach * deliverAmount;

        List<String> lore = plugin.getOrderManager().buildSourceLore(order);
        List<String> coloredLore = new ArrayList<>();
        for (String line : lore) coloredLore.add(ColorUtil.colorize(line));

        ItemStack sourceItem = new ItemStack(mat);
        ItemMeta sourceMeta = sourceItem.getItemMeta();
        if (sourceMeta != null) {
            sourceMeta.setDisplayName(ColorUtil.colorize("&#00fc88" + order.get("owner") + "s Order"));
            sourceMeta.setLore(coloredLore);
            sourceMeta.getPersistentDataContainer().set(
                    new org.bukkit.NamespacedKey(Order.getInstance(), "order_id"),
                    org.bukkit.persistence.PersistentDataType.INTEGER,
                    ((Number) order.get("id")).intValue()
            );
            sourceItem.setItemMeta(sourceMeta);
        }
        inv.setItem(13, sourceItem);

        // Confirm
        inv.setItem(15, GUIBuilder.buildItem(Material.LIME_STAINED_GLASS_PANE,
                ColorUtil.colorize("&#04fc04ᴄᴏɴғɪʀᴍ"),
                List.of(ColorUtil.colorize("&fClick to confirm delivery"),
                        ColorUtil.colorize("&7(" + plugin.getOrderManager().formatCurrency(payout) + ")"))));

        player.openInventory(inv);
    }
}
