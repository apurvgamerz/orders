package de.rydersmp.ryderOrder.GUI;

import de.rydersmp.ryderOrder.Order;
import de.rydersmp.ryderOrder.utils.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public class ListMaterialsGUI {

    private final Order plugin;

    public ListMaterialsGUI(Order plugin) {
        this.plugin = plugin;
    }

    public void open(Player player, int page, String filter, String search) {
        Inventory inv = Bukkit.createInventory(null, 54,
                ColorUtil.colorize("&8ʀʏᴅᴇʀᴏʀᴅᴇʀs -> Select Item"));

        List<Material> materials;
        if (search != null && !search.isEmpty()) {
            materials = plugin.getMaterialsManager().search(search);
        } else {
            materials = plugin.getMaterialsManager().filter(filter);
        }

        int perPage = 45;
        int start = (page - 1) * perPage;
        int end = Math.min(start + perPage, materials.size());

        for (int i = start; i < end; i++) {
            Material mat = materials.get(i);
            ItemStack item = new ItemStack(mat);
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(ColorUtil.colorize("&#00fc88" + formatMaterialName(mat)));
                meta.setLore(List.of(ColorUtil.colorize("&fClick to select")));
                item.setItemMeta(meta);
            }
            inv.setItem(i - start, item);
        }

        // Prev
        if (page > 1) {
            inv.setItem(45, GUIBuilder.buildItem(Material.ARROW,
                    ColorUtil.colorize("&#00fc88ᴘʀᴇᴠɪᴏᴜꜱ"),
                    List.of(ColorUtil.colorize("&fClick to go to the previous page"))));
        }
        // Sort
        inv.setItem(48, GUIBuilder.buildItem(Material.CAULDRON, ColorUtil.colorize("&#00fc88ꜱᴏʀᴛ")));
        // Filter
        inv.setItem(49, GUIBuilder.buildItem(Material.HOPPER, ColorUtil.colorize("&#00fc88ꜰɪʟᴛᴇʀ")));
        // Search
        inv.setItem(50, GUIBuilder.buildItem(Material.OAK_SIGN, ColorUtil.colorize("&#00fc88sᴇᴀʀᴄʜ"),
                List.of(ColorUtil.colorize("&fClick to search"))));
        // Next
        if (end < materials.size()) {
            inv.setItem(53, GUIBuilder.buildItem(Material.ARROW,
                    ColorUtil.colorize("&#00fc88ɴᴇxᴛ"),
                    List.of(ColorUtil.colorize("&fClick to go to the next page"))));
        }

        player.openInventory(inv);
    }

    private String formatMaterialName(Material mat) {
        String[] words = mat.name().split("_");
        StringBuilder sb = new StringBuilder();
        for (String word : words) {
            if (!sb.isEmpty()) sb.append(" ");
            sb.append(word.charAt(0)).append(word.substring(1).toLowerCase());
        }
        return sb.toString();
    }
}
