package de.rydersmp.ryderOrder.GUI;

import de.rydersmp.ryderOrder.Manager.TimeChecker;
import de.rydersmp.ryderOrder.Order;
import de.rydersmp.ryderOrder.utils.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

public class OrderGUI {

    private final Order plugin;

    public OrderGUI(Order plugin) {
        this.plugin = plugin;
    }

    public void open(Player player, int page, String sortKey, String filterKey) {
        Inventory inv = Bukkit.createInventory(null, 54,
                ColorUtil.colorize("&8ʀʏᴅᴇʀᴏʀᴅᴇʀs (Page " + page + ")"));

        List<Map<String, Object>> orders = plugin.getDataManager().getActiveOrders();

        // apply filter
        if (filterKey != null && !filterKey.equals("all")) {
            orders.removeIf(o -> {
                try {
                    Material mat = Material.valueOf((String) o.get("material"));
                    return !plugin.getMaterialsManager().filter(filterKey).contains(mat);
                } catch (Exception e) { return true; }
            });
        }

        // apply sort
        if (sortKey != null) {
            switch (sortKey) {
                case "most_money" -> orders.sort((a, b) -> {
                    double pa = ((Number) a.get("price_per_item")).doubleValue() * ((Number) a.get("amount")).intValue();
                    double pb = ((Number) b.get("price_per_item")).doubleValue() * ((Number) b.get("amount")).intValue();
                    return Double.compare(pb, pa);
                });
                case "most_delivered" -> orders.sort((a, b) ->
                        Integer.compare(((Number) b.get("delivered")).intValue(), ((Number) a.get("delivered")).intValue()));
                case "most_recent" -> orders.sort((a, b) ->
                        Long.compare(((Number) b.get("created_at")).longValue(), ((Number) a.get("created_at")).longValue()));
                case "most_paid_per_item" -> orders.sort((a, b) ->
                        Double.compare(((Number) b.get("price_per_item")).doubleValue(), ((Number) a.get("price_per_item")).doubleValue()));
            }
        }

        int perPage = 45;
        int start = (page - 1) * perPage;
        int end = Math.min(start + perPage, orders.size());

        for (int i = start; i < end; i++) {
            Map<String, Object> order = orders.get(i);
            inv.setItem(i - start, buildOrderItem(order));
        }

        // Navigation bar
        // Previous page
        if (page > 1) {
            inv.setItem(45, GUIBuilder.buildItem(Material.ARROW,
                    ColorUtil.colorize("&#00fc88ᴘʀᴇᴠɪᴏᴜꜱ"), List.of(ColorUtil.colorize("&fClick to go to the previous page"))));
        }
        // Sort
        inv.setItem(47, GUIBuilder.buildItem(Material.CAULDRON, ColorUtil.colorize("&#00fc88ꜱᴏʀᴛ")));
        // Filter
        inv.setItem(48, GUIBuilder.buildItem(Material.HOPPER, ColorUtil.colorize("&#00fc88ꜰɪʟᴛᴇʀ")));
        // Refresh
        inv.setItem(49, GUIBuilder.buildItem(Material.PAPER, ColorUtil.colorize("&#00fc88ᴏʀᴅᴇʀs"),
                List.of(ColorUtil.colorize("&fClick to refresh"))));
        // Search
        inv.setItem(50, GUIBuilder.buildItem(Material.OAK_SIGN, ColorUtil.colorize("&#00fc88sᴇᴀʀᴄʜ"),
                List.of(ColorUtil.colorize("&fClick to search"))));
        // Your orders
        inv.setItem(51, GUIBuilder.buildItem(Material.CHEST, ColorUtil.colorize("&#00fc88ʏᴏᴜʀ ᴏʀᴅᴇʀs"),
                List.of(ColorUtil.colorize("&fClick to view your orders"))));
        // Next page
        if (end < orders.size()) {
            inv.setItem(53, GUIBuilder.buildItem(Material.ARROW,
                    ColorUtil.colorize("&#00fc88ɴᴇxᴛ"), List.of(ColorUtil.colorize("&fClick to go to the next page"))));
        }

        player.openInventory(inv);
    }

    private ItemStack buildOrderItem(Map<String, Object> order) {
        Material mat;
        try {
            mat = Material.valueOf((String) order.get("material"));
        } catch (Exception e) {
            mat = Material.STONE;
        }

        List<String> lore = plugin.getOrderManager().buildSourceLore(order);
        List<String> coloredLore = new ArrayList<>();
        for (String line : lore) coloredLore.add(ColorUtil.colorize(line));

        String ownerName = (String) order.get("owner");
        String name = ColorUtil.colorize("&#00fc88" + ownerName + "s Order");

        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            meta.setLore(coloredLore);
            // Store order ID in persistent data
            meta.getPersistentDataContainer().set(
                    new org.bukkit.NamespacedKey(de.rydersmp.ryderOrder.Order.getInstance(), "order_id"),
                    org.bukkit.persistence.PersistentDataType.INTEGER,
                    ((Number) order.get("id")).intValue()
            );
            item.setItemMeta(meta);
        }
        return item;
    }
}
