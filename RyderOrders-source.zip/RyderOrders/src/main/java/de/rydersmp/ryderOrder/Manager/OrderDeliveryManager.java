package de.rydersmp.ryderOrder.Manager;

import de.rydersmp.ryderOrder.Order;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Map;

public class OrderDeliveryManager {

    public enum DeliveryResult { SUCCESS, NO_ITEMS, INVENTORY_FULL, ORDER_NOT_AVAILABLE, CANNOT_DELIVER_OWN, EXPIRED, ALREADY_DELIVERED, NO_MONEY }
    public enum PaymentResult { SUCCESS, FAILED }
    public enum CancelResult { SUCCESS, REFUNDED }
    public enum CollectResult { SUCCESS, NOTHING_TO_COLLECT, INVENTORY_FULL }

    private final Order plugin;

    public OrderDeliveryManager(Order plugin) {
        this.plugin = plugin;
    }

    public DeliveryResult attemptDelivery(Player deliverer, Map<String, Object> order, int deliverAmount) {
        String ownerUuid = (String) order.get("owner_uuid");
        if (ownerUuid.equals(deliverer.getUniqueId().toString())) return DeliveryResult.CANNOT_DELIVER_OWN;

        int expired = ((Number) order.get("expired")).intValue();
        int deleted = ((Number) order.get("deleted")).intValue();
        if (expired == 1 || deleted == 1) return DeliveryResult.ORDER_NOT_AVAILABLE;

        long createdAt = ((Number) order.get("created_at")).longValue();
        long expireSeconds = plugin.getConfig().getLong("expire-time-seconds", 604800);
        if (TimeChecker.isExpired(createdAt, expireSeconds)) {
            plugin.getDataManager().expireOrder(((Number) order.get("id")).intValue());
            return DeliveryResult.EXPIRED;
        }

        int required = ((Number) order.get("amount")).intValue();
        int delivered = ((Number) order.get("delivered")).intValue();
        if (delivered >= required) return DeliveryResult.ALREADY_DELIVERED;

        Material mat = Material.valueOf((String) order.get("material"));
        int remaining = required - delivered;
        int toDeliver = Math.min(deliverAmount, remaining);

        // check deliverer has items
        if (countItems(deliverer, mat) < toDeliver) return DeliveryResult.NO_ITEMS;

        // check economy
        double priceEach = ((Number) order.get("price_per_item")).doubleValue();
        double payment = priceEach * toDeliver;
        if (plugin.getEconomy() == null) return DeliveryResult.NO_ITEMS;

        // deduct items
        removeItems(deliverer, mat, toDeliver);

        // add to collect queue for owner
        int orderId = ((Number) order.get("id")).intValue();
        plugin.getDataManager().addCollectItem(orderId, mat.name(), toDeliver);
        plugin.getDataManager().updateDelivery(orderId, toDeliver, payment);

        // pay deliverer
        plugin.getEconomy().depositPlayer(deliverer, payment);

        return DeliveryResult.SUCCESS;
    }

    public CollectResult collectItems(Player owner, Map<String, Object> order) {
        String collectStr = (String) order.get("items_to_collect");
        if (collectStr == null || collectStr.isEmpty()) return CollectResult.NOTHING_TO_COLLECT;

        String[] entries = collectStr.split(",");
        for (String entry : entries) {
            String[] parts = entry.split(":");
            if (parts.length < 2) continue;
            Material mat = Material.valueOf(parts[0]);
            int amount = Integer.parseInt(parts[1]);

            if (owner.getInventory().firstEmpty() == -1) return CollectResult.INVENTORY_FULL;
            owner.getInventory().addItem(new ItemStack(mat, amount));
        }

        plugin.getDataManager().clearCollectItems(((Number) order.get("id")).intValue());
        return CollectResult.SUCCESS;
    }

    public CancelResult cancelOrder(Player owner, Map<String, Object> order) {
        int orderId = ((Number) order.get("id")).intValue();
        double paidAmount = ((Number) order.get("paid_amount")).doubleValue();

        plugin.getDataManager().cancelOrder(orderId);

        // refund any uncollected paid amount
        if (paidAmount > 0 && plugin.getEconomy() != null) {
            // Refund what hasn't been paid out yet (paid amount was already given to deliverers)
            // Here we just cancel - actual refund logic depends on server economy rules
        }

        return CancelResult.SUCCESS;
    }

    private int countItems(Player player, Material mat) {
        int count = 0;
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && item.getType() == mat) count += item.getAmount();
        }
        return count;
    }

    private void removeItems(Player player, Material mat, int amount) {
        int remaining = amount;
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length && remaining > 0; i++) {
            ItemStack item = contents[i];
            if (item == null || item.getType() != mat) continue;
            int remove = Math.min(item.getAmount(), remaining);
            item.setAmount(item.getAmount() - remove);
            remaining -= remove;
            if (item.getAmount() == 0) player.getInventory().setItem(i, null);
        }
    }
}
