package de.rydersmp.ryderOrder.Manager;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ConfirmDeliveryManager {

    public static class DeliveryData {
        public int orderId;
        public int amount;
        public DeliveryData(int orderId, int amount) {
            this.orderId = orderId;
            this.amount = amount;
        }
    }

    private final Map<UUID, DeliveryData> pending = new HashMap<>();

    public void setPending(UUID uuid, int orderId, int amount) {
        pending.put(uuid, new DeliveryData(orderId, amount));
    }

    public DeliveryData getPending(UUID uuid) {
        return pending.get(uuid);
    }

    public void clearPending(UUID uuid) {
        pending.remove(uuid);
    }
}
