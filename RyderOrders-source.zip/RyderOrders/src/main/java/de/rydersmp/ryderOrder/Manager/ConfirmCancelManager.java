package de.rydersmp.ryderOrder.Manager;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ConfirmCancelManager {

    private final Map<UUID, Integer> pendingCancel = new HashMap<>();

    public void setPending(UUID uuid, int orderId) {
        pendingCancel.put(uuid, orderId);
    }

    public int getPending(UUID uuid) {
        return pendingCancel.getOrDefault(uuid, -1);
    }

    public void clearPending(UUID uuid) {
        pendingCancel.remove(uuid);
    }
}
