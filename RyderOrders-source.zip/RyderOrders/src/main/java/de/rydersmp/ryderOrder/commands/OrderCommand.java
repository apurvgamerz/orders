package de.rydersmp.ryderOrder.commands;

import de.rydersmp.ryderOrder.Order;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class OrderCommand implements CommandExecutor {

    private final Order plugin;

    public OrderCommand(Order plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getLangManager().getMessage("only-players"));
            return true;
        }

        if (!player.hasPermission("order.use")) {
            plugin.getLangManager().sendMessage(player, "no-permission");
            return true;
        }

        if (args.length == 0) {
            plugin.getOrderGUI().open(player, 1, "most_recent", "all");
            return true;
        }

        if (args[0].equalsIgnoreCase("reload")) {
            if (!player.hasPermission("order.admin")) {
                plugin.getLangManager().sendMessage(player, "no-permission");
                return true;
            }
            plugin.reloadConfig();
            plugin.getLangManager().loadLang();
            plugin.getMaterialsManager().load();
            plugin.getLangManager().sendMessage(player, "plugin-reloaded");
            return true;
        }

        // Show usage
        player.hasPermission("order.admin")
                ? player.sendMessage(plugin.getLangManager().getCommandUsageAdmin())
                : player.sendMessage(plugin.getLangManager().getCommandUsage());
        return true;
    }
}
