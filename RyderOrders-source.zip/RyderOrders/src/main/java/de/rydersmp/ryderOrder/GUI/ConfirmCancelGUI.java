package de.rydersmp.ryderOrder.GUI;

import de.rydersmp.ryderOrder.Order;
import de.rydersmp.ryderOrder.utils.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ConfirmCancelGUI {

    private final Order plugin;

    public ConfirmCancelGUI(Order plugin) {
        this.plugin = plugin;
    }

    public void open(Player player, Map<String, Object> order) {
        Inventory inv = Bukkit.createInventory(null, 27,
                ColorUtil.colorize("&8ʀʏᴅᴇʀᴏʀᴅᴇʀs -> Cancel Order"));

        // Cancel (go back)
        inv.setItem(11, GUIBuilder.buildItem(Material.RED_STAINED_GLASS_PANE,
                ColorUtil.colorize("&#fc0404ᴄᴀɴᴄᴇʟ"),
                List.of(ColorUtil.colorize("&fClick to go back"))));

        // Source item
        Material mat;
        try { mat = Material.valueOf((String) order.get("material")); }
        catch (Exception e) { mat = Material.STONE; }

        List<String> lore = plugin.getOrderManager().buildSourceLore(order);
        List<String> coloredLore = new ArrayList<>();
        for (String line : lore) coloredLore.add(ColorUtil.colorize(line));

        ItemStack sourceItem = new ItemStack(mat);
        ItemMeta sourceMeta = sourceItem.getItemMeta();
        if (sourceMeta != null) {
            sourceMeta.setDisplayName(ColorUtil.colorize("&#00fc88" + order.get("owner") + "s Order"));
            sourceMeta.setLore(coloredLore);
            sourceItem.setItemMeta(sourceMeta);
        }
        inv.setItem(13, sourceItem);

        // Confirm cancel
        inv.setItem(15, GUIBuilder.buildItem(Material.LIME_STAINED_GLASS_PANE,
                ColorUtil.colorize("&#04fc04ᴀᴄᴄᴇᴘᴛ"),
                List.of(ColorUtil.colorize("&fClick to cancel order"))));

        player.openInventory(inv);
    }
}
