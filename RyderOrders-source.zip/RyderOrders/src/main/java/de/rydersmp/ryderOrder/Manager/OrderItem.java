package de.rydersmp.ryderOrder.Manager;

import org.bukkit.Material;

public class OrderItem {
    private final Material material;
    private final int amount;
    private final double pricePerItem;

    public OrderItem(Material material, int amount, double pricePerItem) {
        this.material = material;
        this.amount = amount;
        this.pricePerItem = pricePerItem;
    }

    public Material getMaterial() { return material; }
    public int getAmount() { return amount; }
    public double getPricePerItem() { return pricePerItem; }
    public double getTotalPrice() { return pricePerItem * amount; }
}
